в папці "nedoprogrammisty" треба відкрити .ехе файл "nedoprogrammisty_about"
ОБОВ'ЯЗКОВО МАТИ .NET 10 TA .NET 4.7.2!!!

© Підліток з групи "nedoProgrammisty", усі права захищені (мабуть)